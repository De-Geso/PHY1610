// @file helloworld.cpp
// Hello world rogram in C++
// on cluster use:
// ssh USERNAME@teach.scinet.utoronto.ca
// module load gcc/12
// Compile with g++ -std=c++17
#include <iostream>
using std::cout;

int main()
{
	cout << "Hello, world!\n";
}
