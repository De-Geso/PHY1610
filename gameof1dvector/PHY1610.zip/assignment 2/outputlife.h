// outputlife.h
// Holds screen output for game of life.
#ifndef OUTPUTLIFE_H
#define OUTPUTLIFE_H

#include "initlife.h"

void dump_cells(Cells& cell, int const num_cells, int const step);

#endif
