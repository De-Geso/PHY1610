Parallelized update_all_cells, and output_alive_cells with OpenMP.
update_all_cells was clearly parallelizable. There's just the one for loop, and there's nothing to think about.
output_alive_cells was only partially parallelizable. The first loop, which finds where the alive cells parallelizes nicely.
However, the other two output loops do not parallelize nicely. The order matters for the output, so more cores don't really help us out.
We'd have to do something atomic or critical, and the loops are only one step, so we aren't really saving anything.

In timing.txt, I have the number of threads and runtimes. The first batch is for the attempt with everything parallelized.
It actually does worse with more threads. I think it's because the second two loops don't parallelize well, so I'm just wasting time
passing memory around. This passing around is worse with more cores because there's no passing.
The second batch is for the current state of the system where the parallelization is only done selectively. It runs faster with more
cores, as you'd expect.

Program should run on teach.

source teachsetup
to load modules

make integrated_test
should compile, and compare output with saved original outputs in both output forms.
