#!/bin/bash
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=16
#SBATCH --time=0:60:00
#SBATCH --output=output_parallel.txt

source teachsetup

for i in {1..16}
do
    start=$(date +%s)
    export OMP_NUM_THREADS=$i
    ./gameoflife 1000 1000 1000 0.183 1
    end=$(date +%s)
    echo -e "Threads: $OMP_NUM_THREADS\tElapsed Time (s): $(($end-$start))" >> timing.txt
done
