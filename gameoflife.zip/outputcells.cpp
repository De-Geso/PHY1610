// outputcells.cpp
//
// see outputcells.h for documentation
//
// This code is part of assignment 10 of the 2024 Winter PHY1610 course.
//
// Ramses van Zon, 2024, University of Toronto
// 

#include "outputcells.h"
// #include <algorithm>

void output_cells(std::ostream& out, int step, const Cells& cell)
{
    const int num_rows = cell.extent(0);
    const int num_cols = cell.extent(1);
    const char on_char = 'I', off_char = '-';
    double alive_fraction = 0.0;
    for (auto& onecell: cell)
        if (onecell == alive)
            alive_fraction++;
    alive_fraction /= cell.size();
    out << step << "\t";
    for (int j = 0; j < num_cols; j++)
        if (cell[0][j] == alive)
            out << on_char;
        else
            out << off_char;
    out << " " << alive_fraction << "\n";
    for (int i = 1; i < num_rows; i++) {
        out << "\t";
        for (int j = 0; j < num_cols; j++)
            if (cell[i][j] == alive)
                out << on_char;
            else
                out << off_char;
        out << "\n";
    }
}

void output_alive_cells(std::ostream& out, int step, const Cells& cell)
{
    const int num_rows = cell.extent(0);
    const int num_cols = cell.extent(1);
    double alive_fraction = 0.0;
    #pragma omp parallel for default(none) shared(cell) reduction(+:alive_fraction)
    for (auto& onecell: cell)
        if (onecell == alive)
            alive_fraction++;
    rvector<int> alive_list(alive_fraction);
    int n = 0;
    // #pragma omp parallel for collapse(2)
    // Doesn't actually speed things up when parallel
    for (int i = 0; i < num_rows; i++)
        for (int j = 0; j < num_cols; j++)
	    if (cell[i][j] == alive)
    // #pragma omp critical
   		alive_list[n++] = i*num_cols + j;
   	// std::sort(alive_list.begin(), alive_list.end());
    alive_fraction /= cell.size();
    out << step << "\t/";
    // I don't think I can parallelize this one.
    // The threads are all going to be writing to out, so the output will not be in order.
    // If I try to force it to be in order, it'll probably just be slower than the linear case
    // because of all the memory passing around.
    for (const auto& x: alive_list)
        out << x << '/';
    out << "\t" << alive_fraction << "\n";
}
